import odoo.fields
from odoo import models, fields, api, _
from odoo.exceptions import UserError

"""This class subject to add new subject in the levels"""
class Subjects(models.Model):
    _name = "subjectss.subjects"

    name = fields.Char()
    description = fields.Text()
    year_id = fields.Many2one("year.year",string="Level")
    full_mark = fields.Float()










