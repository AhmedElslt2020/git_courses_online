from datetime import date
from odoo import models, fields, api
from odoo.exceptions import UserError
import re
from datetime import datetime

""" This class to create student  but not editable and see the graduated students"""
class Student(models.Model):
    _name = "studentss.studentss"
    _order = "name asc"

    name = fields.Char(placeholder="enter your name")
    name_of_arabic = fields.Char()
    number_id = fields.Char()
    image = fields.Image(string="picture")
    address = fields.Text()
    date_of_birth = fields.Date()
    age = fields.Integer(compute='calc_age_student', store=True)
    phone = fields.Char(string="Phone", help="enter your phone number")
    email = fields.Char(placeholder="admin@gmail.com")
    gender = fields.Selection([("male", "male"), ("female", "female")], default="female")
    priority = fields.Selection([("0", "normal"), ("1", "low"), ("2", "high"), ("3", "very high")])
    qualify = fields.Selection([
        ('high_school', 'high school'),
        ('technical_secondary', 'technical_secondary'),
        ('the_outside', 'the_outside'),
    ],string="Qualification")
    image_qualify = fields.Image(string="Qualification Attachment")
    date_of_join = fields.Date()
    father_job = fields.Char(string="Father job")
    nationality = fields.Selection([("egyptian", "egyptian"), ("other", "other")], default="egyptian")
    other = fields.Char()
    army_state = fields.Selection([("exempt", "exempt"), ("muggle", "muggle"), ("finished", "finished")])
    academic_record = fields.Char()
    student_total_mark = fields.Integer(compute="comput_student_total_mark")
    graduated= fields.Boolean(string="Graduated")
    academic_history_ids = fields.One2many("academicss.history","student_id",string="Academic History")
    sum_year_total = fields.Float(compute="compute_sum_year_total")
    student_total_precentage = fields.Float(compute="compute_sum_year_total")


    @api.depends('date_of_birth')
    def calc_age_student(self):
        """ calculate age from data_of_birth"""
        for rec in self:
            today = date.today()
            if rec.date_of_birth:
                rec.age = today.year - rec.date_of_birth.year
            else:
                rec.age = 1


    @api.model_create_multi
    def create(self, vals_list):
        """ this sequence takes ids automatically"""
        for vals in vals_list:
            vals['number_id'] = self.env['ir.sequence'].next_by_code('studentss.studentss')
        return super(Student, self).create(vals_list)


    def comput_student_total_mark(self):
        """calculates the total mark to the student and not sum the subject less than 50"""
        for rec in self:
                rec.student_total_mark = sum(
                    rec.academic_history_ids.mapped("mark_ids").filtered(lambda x: x.precentage > .50).mapped(
                        "student_mark"))



    def compute_sum_year_total(self):
        for rec in self:

            rec.sum_year_total = sum(rec.academic_history_ids.mapped("year_id").mapped("sum_mark_year"))
            if rec.student_total_mark or rec.sum_year_total:
                rec.student_total_precentage = rec.student_total_mark / rec.sum_year_total
            else:
                rec.student_total_precentage = 0



