# -*- coding: utf-8 -*-

from . import student
from . import academics_history
from . import year
from . import marks
from . import subjects
from . import academic_history_student




