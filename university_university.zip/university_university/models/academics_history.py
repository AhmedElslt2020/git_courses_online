from odoo import models, fields, api
from datetime import datetime
from datetime import date
from odoo.exceptions import UserError

"""this class to see the details of student and make the accord the subject and see the percentage in this year"""


class AcademicsHistory(models.Model):
    _name = "academicss.history"
    _rec_name = 'student_year'
    _order = "year_id,student_id asc"
    # _order = "year_id,subject_total_mark"

    default_year = fields.Char(
        default=lambda self: str(datetime.today().year), string="Academic Year")

    student_id = fields.Many2one("studentss.studentss", order='student_id asc')
    year_id = fields.Many2one("year.year", string="Level")
    student_year = fields.Char(compute='_name_get', store=True)
    state = fields.Selection(
        [("fresh", "Fresh"), ("re", "Remaining"), ("chance", "Chance"),
         ])
    numer_of_seats = fields.Char(string="Student Seat")
    numer_of_chair = fields.Integer(string="Chair Number")
    numer_of_section = fields.Integer(string="Class")
    age = fields.Integer(compute='calc_age_students', store=True)
    date_first = fields.Date()
    date_ends = fields.Date()
    mark_ids = fields.One2many("marks.marks", "academic_history_id")

    subject_total_mark = fields.Float(compute='calc_year_total_mark', store=True, string="Student Total Mark")

    year_total_mark = fields.Float(compute='calc_sum_mark_student_precentage', default=0,
                                   store=True, string="Student Percentage")
    my_boolean = fields.Boolean()

    # @api.model
    # def search(self, args, offset=0, limit=None, order=None, count=False):
    #     """calculates the sort subject and make limit=5"""
    #     academic_hist = super(AcademicsHistory, self).search(args, offset=offset, limit=limit, order=order, count=count)
    #     print("Context ", self._context)
    #     if self._context.get('from_the_first'):
    #         academic_hist = academic_hist.sorted('year_total_mark', reverse=True)
    #         if len(academic_hist) > self._context.get('default_limit', 4):
    #             academic_hist = academic_hist[:self._context.get('default_limit', 4)]
    #     return academic_hist

    @api.depends('student_id.date_of_birth')
    def calc_age_students(self):
        """cal age to make domain"""
        for rec in self:
            today = date.today()
            if rec.student_id.date_of_birth:
                rec.age = today.year - rec.student_id.date_of_birth.year
            else:
                rec.age = 1

    @api.constrains("age", 'student_id.gender')
    def check_track_id(self):
        """this function domain to rfuse register if egypt male and great 28"""

        if self.age > 28 and self.student_id.gender == 'male' and self.student_id.state_of_army == 'muggle':
            raise UserError("you must enter army")

        else:
            print("write")
# the right function
    # @api.depends('mark_ids.student_mark', 'mark_ids')
    # def calc_year_total_mark(self):
    #     for rec in self:
    #         rec.subject_total_mark = sum(rec.mark_ids.mapped('student_mark'))

    # @api.depends('mark_ids.student_mark', 'mark_ids')
    # def calc_year_total_mark(self):
    #     for rec in self:
    #         rec.subject_total_mark = sum(rec.mark_ids.filtered(lambda x: x.year_id.id in [rec.year_id.id]).mapped('student_mark'))
    # # if you want to add smaller than 50
    @api.depends('mark_ids.student_mark', 'mark_ids')
    def calc_year_total_mark(self):
        for rec in self:
            filtered_marks = rec.mark_ids.filtered(lambda x: x.year_id.id == rec.year_id.id and x.student_mark > 50)
            rec.subject_total_mark = sum(filtered_marks.mapped('student_mark'))



    @api.depends("subject_total_mark", "year_id")
    def calc_sum_mark_student_precentage(self):
        """this function calculates the sum of the student marks"""
        for rec in self:
            if rec.subject_total_mark or rec.year_id:
                rec.year_total_mark = rec.subject_total_mark / rec.year_id.sum_mark_year

            else:
                rec.year_total_mark = 0

    @api.depends("student_id.name", "default_year", "year_id.name")
    def _name_get(self):
        """This function to make name of student next to level next year and make it in rec_name to appear to user"""
        news_list = []
        for record in self:
            news = str(record.student_id.name) + "/" + str(record.year_id.name) + str(record.default_year)
            record.student_year = news


    @api.model_create_multi
    def create(self, vals_list):
        """ this field to make right and visible not edit"""

        for vals in vals_list:
            vals['my_boolean'] = True

        return super(AcademicsHistory, self).create(vals_list)


