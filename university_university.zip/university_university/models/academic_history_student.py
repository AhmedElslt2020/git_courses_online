# -*- coding: utf-8 -*-

import base64
from collections import OrderedDict
from datetime import datetime

from odoo import http
from odoo.exceptions import AccessError, MissingError
from odoo.http import request, Response
from odoo.tools import image_process
from odoo.tools.translate import _
from odoo.addons.portal.controllers import portal
from odoo.addons.portal.controllers.portal import pager as portal_pager
from datetime import datetime
from datetime import date


class AcademicHistory(http.Controller):

    @http.route('/my/resignations/form', type="http", auth='public', website=True, csrf=True)
    def student_academic_form_view(self, **kwargs):
        student_list = request.env["studentss.studentss"].sudo().search([])
        year_list = request.env["year.year"].sudo().search([])
        subjects = request.env["subjectss.subjects"].sudo().search([])
        # student_list = request.env["studentss.studentss"].sudo().search([])

        return request.render('university_university.student_post_form',
                              {'years': year_list, 'students': student_list, 'subjects': subjects})

    @http.route('/my/sale/create', type="http", auth='public', website=True, csrf=True)
    def request_submit(self, **kwargs):
        print("kwargs ", kwargs)
        """
        kwargs  {'student_id': '2', 'year_id': '1',
          'numer_of_seats': '11', 'numer_of_chair': '14',
          'subjects': '1', 'subject_id_1': '2', 'degree_1': '55.5',
           'subject_id_2': '1', 'degree_2': '55.1', 'subject_id_3': '3',
            'degree_3': '100'}
        """
        student_id = kwargs.get('student_id', False)
        year_id = kwargs.get('year_id', False)

        numer_of_seats = kwargs.get('numer_of_seats', 0)
        numer_of_chair = kwargs.get('numer_of_chair', 0)
        numer_of_section= kwargs.get('numer_of_section', 0)
        state = kwargs.get('state', 0)
        mark_lines = []
        for key in kwargs.keys():
            if "subject_id_" in key:
                subject_value = int(key.split("_")[2])
                subject_index = "subject_id_" + str(subject_value)
                degree_index = "degree_" + str(subject_value)
                subject = int(kwargs.get(subject_index, False))
                degree = float(kwargs.get(degree_index, False))
                mark_lines.append({'subject_id': subject, 'degree': degree})

        print("mark_lines ", mark_lines)
        vals = {
            'student_id': int(student_id),
            'year_id': int(year_id),

            'numer_of_seats': numer_of_seats,
            'numer_of_chair': numer_of_chair,
            'numer_of_section': numer_of_section,
            'state': state,
            'mark_ids': [(0, 0, value) for value in mark_lines]
        }
        print("vals ", vals)
        request.env['academicss.history'].sudo().create(vals)
        response = http.request.render('university_university.create_employee_done_template',
                                       {'page_name': 'expense_create_done'})

        return response
# function create student
    @http.route('/my/student/form', type="http", auth='public', website=True, csrf=True)
    def student_resignation_form_view(self, **kwargs):
        # student_list = request.env["studentss.studentss"].sudo().search([])
        # year_list = request.env["year.year"].sudo().search([])
        # subjects = request.env["subjectss.subjects"].sudo().search([])


        return request.render('university_university.create_student_post_form'
                              )


    @http.route('/my/student/create', type="http", auth='public', website=True, csrf=True)
    def request_submits(self, **kwargs):
        print("kwargs ", kwargs)
        """
        kwargs  {'student_id': '2', 'year_id': '1',
          'numer_of_seats': '11', 'numer_of_chair': '14',
          'subjects': '1', 'subject_id_1': '2', 'degree_1': '55.5',
           'subject_id_2': '1', 'degree_2': '55.1', 'subject_id_3': '3',
            'degree_3': '100'}
        """
        # student_id = kwargs.get('student_id', False)
        # year_id = kwargs.get('year_id', False)

        name = kwargs.get('name', 0)
        date_of_birth = kwargs.get('date_of_birth', 0)
        gender = kwargs.get('gender', 0)
        address = kwargs.get('address', 0)
        father_job = kwargs.get('father_job', 0)
        phone = kwargs.get('phone', 0)
        # numer_of_chair = kwargs.get('numer_of_chair', 0)
        # numer_of_section = kwargs.get('numer_of_section', 0)
        # state = kwargs.get('state', 0)

        vals = {
            'name': name,
            'date_of_birth': date_of_birth,
            'gender': gender,
            'address': address,
            'father_job': father_job,
            'phone': phone,
        }
        print("vals ", vals)
        request.env['studentss.studentss'].sudo().create(vals)
        response = http.request.render('university_university.create_employee_done_template'
                                       )

        return response



    #filter
    @http.route('/my/academic/history', type="http", auth='public', website=True)
    def get_academic_history(self, **kw):
        # Get the selected code from the query parameters or use 'all' by default
        selected_state = request.params.get('state', 'all')
        selected_year_id = request.params.get('year_id', 'all')
        current_year = datetime.today().year

        academic_history = request.env['academicss.history'].sudo().search([('default_year', '=', str(current_year))])


        vals = {
            'my_details': academic_history,
            'page_name': 'academic_history',
            'selected_state': selected_state,
            'selected_year_id': selected_year_id,
        }
        return request.render('university_university.student_academic_detail_form', vals)

    @http.route('/my/academic/history/state/<string:state>', type="http", auth='public', website=True)
    def get_academic_history_filtered(self, state=None, **kw):
        if state and state != 'all':
            domain = [('state', '=', state)]
            academic_history = request.env['academicss.history'].sudo().search(domain)
        else:
            # Handle the case when 'all' is selected or no code is specified
            academic_history = request.env['academicss.history'].sudo().search([])

        vals = {
            'my_details': academic_history,
            'page_name': 'academic_history',
            'selected_state': state,
        }
        return request.render('university_university.student_academic_detail_form', vals)

    @http.route('/my/academic/history/year_id/<string:year_id>', type="http", auth='public', website=True)
    def get_academic_history_filtered_year_id(self, year_id=None, **kw):
        if year_id and year_id != 'all':
            domain = [('year_id', '=', year_id)]
            academic_history = request.env['academicss.history'].sudo().search(domain)
        else:
            # Handle the case when 'all' is selected or no code is specified
            academic_history = request.env['academicss.history'].sudo().search([])

        vals = {
            'my_details': academic_history,
            'page_name': 'academic_history',
            'selected_year_id': year_id,
        }
        return request.render('university_university.student_academic_detail_form', vals)

    # from database
    @http.route('/my/academic/history', type="http", auth='public', website=True)
    def get_sale_orders(self, sortby='id', **kw):
        # sorted_list = {
        #     'id': {'label': 'ID Desc', 'order': 'id desc'},
        #     # 'student_id': {'label': 'student_id', 'order': 'student_id'},
        #
        # }
        # default_order_by = sorted_list[sortby]['order']
        current_year = datetime.today().year

        sale_details = request.env['academicss.history'].sudo().search([('default_year', '=', str(current_year))])
        print("hello")
        return request.render('university_university.student_academic_detail_form', {'my_details': sale_details})

        # links

    @http.route(['/my_sale_details/<int:order_id>'], type="http", website=True, auth='public')
    def get_studente_form(self, order_id, **kw):
        order = request.env['academicss.history'].sudo().browse(order_id)
        vals = {"order": order, 'page_name': 'student_form_view'}

        return request.render('university_university.student_detail_form_shown_link', vals)
    # serch group by student
    @http.route('/my/academic/history/search', type='http', auth='public', website=True)
    def search_academic_history(self, **kw):
        query = kw.get('query', False)

        if query:
            current_year = datetime.today().year
            academic_history = request.env['academicss.history'].sudo().search([
                ('student_id', 'ilike', query),('default_year', '=', str(current_year))


            ])

        else:
            academic_history = request.env['academicss.history'].sudo().search([])

        vals = {
            'my_details': academic_history,
            'page_name': 'academic_history',
            'query': query
        }
        return request.render('university_university.student_academic_detail_form', vals)

    # @http.route('/my/academic/history/search', type='http', auth='public', website=True)
    # def search_academic_history(self, **kw):
    #     query = kw.get('query', False)
    #
    #     today = date.today().strftime("%Y-%m-%d")
    #     academic_history = request.env['academicss.history'].sudo().search(['|',
    #                                                                             ('default_year', '=', query),
    #                                                                             ('default_year', '=', 2022)
    #                                                                             ])
    #
    #     vals = {
    #         'my_details': academic_history,
    #         'page_name': 'academic_history',
    #         'query': query
    #     }
    #     return request.render('university_university.student_academic_detail_form', vals)

    # @http.route('/my/academic/history/search', type='http', auth='public', website=True)
    # def search_academic_history(self, **kw):
    #     query = kw.get('query', False)
    #
    #     # today = date.today().strftime("%Y-%m-%d")
    #     today = date.today().strftime("%Y")
    #
    #
    #     # Set the default domain to the current year
    #     domain = [('default_year', '=', today)]
    #
    #     # Add the query to the domain if it is present
    #     if query:
    #         domain.append(('default_year', '=', query))
    #
    #     else:
    #         domain.append(('default_year', '=', domain))
    #
    #
    #     academic_history = request.env['academicss.history'].sudo().search(domain)
    #
    #     vals = {
    #         'my_details': academic_history,
    #         'page_name': 'academic_history',
    #         'query': query,
    #
    #     }
    #     return request.render('university_university.student_academic_detail_form', vals)

    # context_today().strftime('%Y'))

    # @http.route('/my/academic/history/search', type='http', auth='public', website=True,
    #             default_domain=[('default_year', '=', str(datetime.today().year))])
    # def search_academic_history(self, default_domain=None, **kw):
    #     query = kw.get('query', False)
    #     default_domain = [('default_year', '=', str(datetime.today().year))]
    #
    #     academic_history = request.env['academicss.history'].sudo().search(kw.get('domain', default_domain))
    #
    #     vals = {
    #         'my_details': academic_history,
    #         'page_name': 'academic_history',
    #         'query': query,
    #
    #     }
    #     return request.render('university_university.student_academic_detail_form', vals)


    # this right function but add it in main functio name get_academic_history

    # @http.route('/my/academic/history/search', type='http', auth='public', website=True,
    #             default_domain=[('default_year', '=', str(datetime.today().year))])
    # def search_academic_history(self, default_domain=None, **kw):
    #     query = kw.get('query', False)
    #     current_year = datetime.today().year
    #
    #     if default_domain is None:
    #         default_domain = [('default_year', '=', str(current_year))]
    #
    #     academic_history = request.env['academicss.history'].sudo().search(kw.get('domain', default_domain))
    #     vals = {
    #         'my_details': academic_history,
    #         'page_name': 'academic_history',
    #         'query': query,
    #     }
    #     return request.render('university_university.student_academic_detail_form', vals)


















