import odoo.fields
from odoo import models, fields, api, _

"""This class level to make levels in this system"""
class Year(models.Model):
    _name = "year.year"

    name = fields.Char()

    sum_mark_year = fields.Float(compute='_calc_sum_mark_year', store=True,string="Year Total Mark")
    subject_line_ids = fields.One2many("subjectss.subjects", "year_id")

    @api.depends("subject_line_ids", "subject_line_ids.full_mark")
    def _calc_sum_mark_year(self):
        """This function to sum tho subject in the levels"""
        for rec in self:
            rec.sum_mark_year = sum(rec.subject_line_ids.mapped('full_mark'))




