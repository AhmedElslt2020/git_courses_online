import odoo.fields
from odoo import models, fields, api, _
from odoo.exceptions import UserError
import json

"""This class subject"""
class Marks(models.Model):
    _name = "marks.marks"
    _rec_name = 'subject_id'





    subject_id = fields.Many2one("subjectss.subjects")
    subject_id_domain = fields.Char(compute='_compute_subject_id_domain', readonly=True, store=False)
    student_mark = fields.Float()
    precentage = fields.Float(compute="_calc_precentage",store=True)
    year_id = fields.Many2one(related="subject_id.year_id")
    academic_history_id = fields.Many2one("academicss.history")

    @api.depends('academic_history_id.year_id')
    def _compute_subject_id_domain(self):
        """calculates the domain of subject to appear in the student to choose level to
         appear select subject in the levels only and make subject the last year less than 50"""
        for rec in self:
            selected_subject_ids = self.academic_history_id.mark_ids.mapped('subject_id.id')
            subject_ids = self.env['subjectss.subjects'].search([('year_id','=',rec.academic_history_id.year_id.id)]).ids
            m_objects = self.search([('academic_history_id.student_id','=',rec.academic_history_id.student_id.id)])
            fall_subject_ids = m_objects.filtered(lambda s:s.precentage < .50).mapped('subject_id.id')
            subject_ids = subject_ids + fall_subject_ids
            available_subject_ids = [i for i in subject_ids if i not in selected_subject_ids]
            unique_subject_ids = list(set(available_subject_ids))
            rec.subject_id_domain = json.dumps([('id', 'in',unique_subject_ids)])



    @api.depends('subject_id','student_mark')
    def _calc_precentage(self):
        """ This function to make percentage to student mark"""
        for rec in self:
            if rec.subject_id or rec.student_mark:
                precentages = rec.student_mark / rec.subject_id.full_mark
                print("precentages",precentages)
                rec.precentage = precentages
            else:
                rec.precentage = 1


    @api.constrains("subject_id", 'subject_id.full_mark','student_mark')
    def check_track_id(self):
        """this function domain to rfuse register if egypt male and great 28"""
        for rec in self:
            if rec.student_mark > rec.subject_id.full_mark:
                raise UserError("you must enter degree less full mark")
            else:
                print("write")











