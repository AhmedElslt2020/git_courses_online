# # -*- coding: utf-8 -*-
#
# import base64
# from collections import OrderedDict
# from datetime import datetime
#
# from odoo import http
# from odoo.exceptions import AccessError, MissingError
# from odoo.http import request, Response
# from odoo.tools import image_process
# # -*- coding: utf-8 -*-
#
# import base64
# from collections import OrderedDict
# from datetime import datetime
#
# from odoo import http
# from odoo.exceptions import AccessError, MissingError
# from odoo.http import request, Response
# from odoo.tools import image_process
# from odoo.tools.translate import _
# from odoo.addons.portal.controllers import portal
#
# from odoo.tools import groupby as groupbylem
# from operator import itemgetter
# from odoo.addons.portal.controllers.portal import pager as portal_pager
# #
#
#
#
# class AcademicHistory(http.Controller):
#
#
#     @http.route('/my/resignations/form', type="http", auth='public', website=True, csrf=True)
#     def student_academic_form_view(self, **kwargs):
#         student_list = request.env["studentss.studentss"].sudo().search([])
#         year_list = request.env["year.year"].sudo().search([])
#         # student_list = request.env["studentss.studentss"].sudo().search([])
#
#         return request.render('university_university.student_post_form',
#                               {'years': year_list ,'students':student_list})
#
#
#     @http.route('/my/sale/create', type="http", auth='public', website=True,csrf=True)
#     def request_submit(self,  **kwargs):
#
#
#
#         request.env['academicss.history'].sudo().create(kwargs)
#         response = http.request.render('university_university.create_employee_done_template',
#                                        {'page_name': 'expense_create_done'})
#
#
#         return response
#
#
#
#
#
# # from database
#
#     # @http.route(['/my/academic/history', '/my/academic/history/page/<int:page>'], type="http", auth='public',
#     #                 website=True)
#     # def get_sale_orders(self, **kw):
#     #
#     #     sale_details = request.env['academicss.history'].sudo().search([])
#     #     vals = {'my_details': sale_details,
#     #             'page_name': 'academic_history',
#     #
#     #
#     #             }
#     #
#     #     return request.render('university_university.student_academic_detail_form', vals)
#
#
#     # filter
#     @http.route('/my/academic/history', type="http", auth='public', website=True)
#     def get_academic_history(self, **kw):
#         # Get the selected code from the query parameters or use 'all' by default
#         selected_code = request.params.get('code', 'all')
#
#         academic_history = request.env['academicss.history'].sudo().search([])
#
#         vals = {
#             'my_details': academic_history,
#             'page_name': 'academic_history',
#             'selected_code': selected_code,
#         }
#         return request.render('university_university.student_academic_detail_form', vals)
#
#     @http.route('/my/academic/history/code/<string:code>', type="http", auth='public', website=True)
#     def get_academic_history_filtered(self, code=None, **kw):
#         if code and code != 'all':
#             domain = [('code', '=', code)]
#             academic_history = request.env['academicss.history'].sudo().search(domain)
#         else:
#             # Handle the case when 'all' is selected or no code is specified
#             academic_history = request.env['academicss.history'].sudo().search([])
#
#         vals = {
#             'my_details': academic_history,
#             'page_name': 'academic_history',
#             'selected_code': code,
#         }
#         return request.render('university_university.student_academic_detail_form', vals)
#
#         # links
#
#     @http.route(['/my_sale_details/<int:order_id>'], type="http", website=True, auth='public')
#     def get_studente_form(self, order_id, **kw):
#         order = request.env['academicss.history'].sudo().browse(order_id)
#         vals = {"order": order, 'page_name': 'student_form_view'}
#
#
#         student_records = request.env['academicss.history'].search([])
#         student_ids = student_records.ids
#         student_index = student_ids.index(order.id)
#         if student_index != 0 and student_ids[student_index - 1]:
#             vals['prev_record'] = '/my_sale_details/{}'.format(student_ids[student_index - 1])
#         if student_index < len(student_ids) - 1 and student_ids[student_index + 1]:
#             vals['next_record'] = '/my_sale_details/{}'.format(student_ids[student_index + 1])
#
#         return request.render('university_university.student_detail_form_shown_link', vals)
#
# #
# #
# # class AcademicPortal(portal.CustomerPortal):
# # # counter in menuitem
# #     def _prepare_home_portal_values(self, counters):
# #         values = super()._prepare_home_portal_values(counters)
# #         PurchaseOrder = request.env['academics.history']
# #         domain = [('academic_registration_ids', '!=', False)]
# #
# #         if 'academic_count' in counters:
# #             values['academic_count'] = PurchaseOrder.search_count(domain) if PurchaseOrder.check_access_rights('read',
# #                                                                                                            raise_exception=False) else 0
# #         return values
# #
# #
# # class Academic(http.Controller):
# # # post data to database
# #     @http.route('/my/resignation/form', type="http", auth='public', website=True, csrf=True)
# #     def employee_form_view(self, **kwargs):
# #         student_list = request.env["students.students"].sudo().search([])
# #         level_list = request.env["levels.levels"].sudo().search([])
# #         subject_list = request.env["subjects.subjects"].sudo().search([])
# #         academic_list = request.env["academics.history"].sudo().search([])
# #
# #         return request.render('university_helwan.student_post_form'
# #                               , {'student': student_list, 'level': level_list, 'subject': subject_list,
# #                                  'academic': academic_list})
# #
# #     # get database to web
# #     @http.route('/my/sale/create', type="http", auth='public', website=True, csrf=True)
# #     def request_submit(self, **kwargs):
# #         request.env['registration.registration'].sudo().create(kwargs)
# #         response = http.request.render('university_helwan.create_employee_done_template',
# #                                        {'page_name': 'expense_create_done'})
# #
# #         return response
# #
# #
# # # to open link form
# #     @http.route(['/my_academic_details', '/my_academic_details/page/<int:page>'], type='http', auth="user",
# #                 website=True)
# #     def portal_my_academic(self, page=1, date_begin=None, date_end=None, sortby=None, filterby=None,
# #                            **kw):
# #
# #         template = 'university_helwan.academic_detail_form'
# #
# #         domain = [('academic_registration_ids', '!=', False)]
# #         searchbar_filters = {}
# #         url = '/my_academic_details'
# #         page_name = 'academic_details'
# #         history = 'my_academic_history'
# #         key = 'academics'
# #         name = kw.get('name', False)
# #         values = {
# #             'page_name': 'home',
# #         }
# #         Academic = request.env['academics.history']
# #
# #
# #         if name:
# #             domain += [('name', '=', name)]
# #
# #         searchbar_sortings = {
# #             'name': {'label': _('Name'), 'order': 'name asc, id asc'},
# #         }
# #         # default sort
# #         if not sortby:
# #             sortby = 'name'
# #         order = searchbar_sortings[sortby]['order']
# #         default_filter = kw.get('default_filter')
# #         if searchbar_filters:
# #             # default filter
# #             if not filterby:
# #                 filterby = default_filter
# #             domain += searchbar_filters[filterby]['domain']
# #
# #         # count for pager
# #         count = Academic.search_count(domain)
# #
# #         # make pager
# #         pager = portal_pager(
# #             url=url,
# #             url_args={'date_begin': date_begin, 'date_end': date_end, 'sortby': sortby, 'filterby': filterby},
# #             total=count,
# #             page=page,
# #             step=8
# #         )
# #
# #         # search the student orders to display, according to the pager data
# #         academics = Academic.search(
# #             domain,
# #             order=order,
# #             limit=8,
# #             offset=pager['offset']
# #         )
# #         request.session[history] = academics.ids[:100]
# #
# #         values.update({
# #             'date': date_begin,
# #             key: academics,
# #             'page_name': page_name,
# #             'pager': pager,
# #             'searchbar_sortings': searchbar_sortings,
# #             'sortby': sortby,
# #             'searchbar_filters': OrderedDict(sorted(searchbar_filters.items())),
# #             'filterby': filterby,
# #             'default_url': url,
# #         })
# #         return request.render(template, values)
# # # to links form
# #     @http.route(['/my_academic_details/<int:academic_id>'], type="http", website=True, auth='public')
# #     def get_student_form(self, academic_id, **kw):
# #         academic = request.env['academics.history'].sudo().browse(academic_id)
# #         vals = {"academic": academic, 'page_name': 'academic_form_view', 'history': 'my_academic_history'}
# #
# #         return request.render('university_helwan.student_detail_form_shown_link', vals)
# #
# #
