# -*- coding: utf-8 -*-
{
    'name': "school",

    'summary': """This system is school to help student to register subjects and put degree and calculate the percentge """,
    'sequence': -80001,

    'description': """
       This module to register the data of student , register the subjects 
       , see the details from academic the last year by data student 
       , this year , make register by web or system 
       and make pdf to private details to management of system 
    """,
    'category': '',
    'author': 'Neoteric Hub',
    'website': "https://neoterichub.com",
    'license': '',
    'depends': ['base', 'board', 'website', 'portal', 'web_domain_field'],

    'data': [
        "reports/student_templates.xml",
        "reports/student_report.xml",
        'security/ir.model.access.csv',
        # 'security/university_security.xml',
        'data/sequence_data.xml',
        'views/dashboard.xml',
        'views/student.xml',
        'views/academic_history.xml',
        'views/level.xml',
        'views/marks.xml',
        'views/subject.xml',
        'views/the_top_in_the_school.xml',
        'views/menu.xml',

        'views/website_controll_academic_history_menuitem.xml',
        'views/academic_history_student_web.xml',

    ],
    'demo': [''],
    'installable': True,
    'application': True,
    'auto_install': False,
}
