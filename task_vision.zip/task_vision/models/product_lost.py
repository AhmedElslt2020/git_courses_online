from email.policy import default


from odoo import models, fields, api, tools


class Productlost(models.Model):
    _name = 'product.lost'

    name = fields.Char()
    product_id = fields.Many2one("product.product")
    quantity = fields.Float()
    price_unit = fields.Float(string="price")
    tax_id = fields.Many2many("account.tax", string="Taxes")
    price_subtotal = fields.Float(compute="_compute_calc_total")
    total_price = fields.Float("Total", compute="_get_total_line")
    order_id = fields.Many2one('sale.order')

    @api.depends("quantity", "price_unit")
    def _compute_calc_total(self):
        for rec in self:
            rec.price_subtotal = rec.quantity * rec.price_unit

    @api.depends("price_subtotal")
    def _get_total_line(self):
        for rec in self:
            rec.total_price = rec.price_subtotal
