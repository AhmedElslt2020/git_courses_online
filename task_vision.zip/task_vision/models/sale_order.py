from email.policy import default

from odoo import models, fields, api, tools


class SaleOrder(models.Model):
    _inherit = 'sale.order'

    product_lost_ids = fields.One2many('product.lost', 'order_id')
    cost_total_lines = fields.Float(compute="_get_total_lines", string="Total all")
    cost_tax_amount_total = fields.Float(compute="_compute_tax_amount")
    cost_amount_untaxed = fields.Float(compute="_compute_amount_untaxed")
    user_name = fields.Many2one("res.users")

    def _user_name(self):
        self.user_name = self.env.user.id

    def action_post(self):
        res = super().action_post()
        is_pre_sales = self.env.user.has_group('task_vision.pre_sales_user')
        is_sales_user = self.env.user.has_group('task_vision.sales_user')

        if is_pre_sales and self.total_amount < 100:
            raise ValidationError(_(''))
        if is_sales_user and self.total_amount < 1000:
            raise ValidationError(_(''))

        return res

    @api.depends("product_lost_ids", "product_lost_ids.price_subtotal")
    def _compute_amount_untaxed(self):
        for rec in self:
            rec.cost_amount_untaxed = sum([line.price_subtotal for line in rec.product_lost_ids])

    @api.depends("product_lost_ids", "product_lost_ids.tax_id",
                 "product_lost_ids.price_subtotal", "product_lost_ids.total_price")
    def _get_total_lines(self):
        for record in self:
            sum_tax_included = 0.0
            for line in record.product_lost_ids:
                taxes = line.tax_id.compute_all(line.price_unit, line.order_id.currency_id,
                                                line.quantity, line.product_id, line.order_id.partner_id)
                print("sum_tax_included Taxes ", taxes)
                sum_tax_included += taxes.get('total_included', 0.0)
            record.cost_total_lines = sum_tax_included

    @api.depends('product_lost_ids', 'product_lost_ids.tax_id', 'product_lost_ids.price_subtotal')
    def _compute_tax_amount(self):
        for record in self:
            sum_tax_amount = 0.0
            for line in record.product_lost_ids:
                taxes = line.tax_id.compute_all(line.price_unit, line.order_id.currency_id,
                                                line.quantity, line.product_id, line.order_id.partner_id)
                print("tax_amount_total Taxes ", taxes)
                sum_tax_amount += sum(t.get('amount', 0.0) for t in taxes.get('taxes', []))
            record.cost_tax_amount_total = sum_tax_amount
