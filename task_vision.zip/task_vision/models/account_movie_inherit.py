from email.policy import default

from odoo import models, fields, api, tools
from odoo.exceptions import ValidationError


class AccountMovieInherit(models.Model):
    _inherit = 'account.move'


    def action_post(self):
        res = super(AccountMovieInherit, self).action_post()
        is_pre_sales = self.env.user.has_group('task_vision.pre_sales_user')
        is_sales_user = self.env.user.has_group('task_vision.sales_user')

        if is_pre_sales and self.total_amount < 100:
            raise ValidationError('you should make error')
        if is_sales_user and self.total_amount < 1000:
            raise ValidationError('you should make error')

        return res