{
    "name": "Sale order inherit vision",
    "summary": "Sale order inherit by vision by odoo 15",
    'depends': ['base', "sale", 'account'],
    "data": [
        "security/sale_inherit_security.xml",
        "security/ir.model.access.csv",
        'views/sale_order_inherit.xml',
    ],

    # "application": True,
    # "sequence": -209,
    #
    # "installable": True,

}
