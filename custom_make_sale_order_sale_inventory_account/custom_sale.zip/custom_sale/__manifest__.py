# -*- coding: utf-8 -*-
{
    'name': "custom sale",

    'description': """
        manage logistic from Logistics module """,

    'author': "Neoteric Hub",
    'website': "",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/15.0/odoo/addons/base/data/ir_module_category_data.xml
    # for the full list
    'category': 'Uncategorized',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['base','sale','sale_management','account','stock'],

    # always loaded
    'data': [
        # 'security/group.xml',
        # 'security/ir.model.access.csv',

        'views/custom_sale.xml',
        'views/account_movie_view.xml',
        'views/stock_custom.xml',

    ],
}
