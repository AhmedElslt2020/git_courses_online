from odoo import models, fields,api

class SaleInherit(models.Model):
    _inherit = "sale.order"


    responsible_id = fields.Many2one("res.users")


    # eng by function in odoo trasfer from sale to invoice#
    def _prepare_invoice(self):
        invoice_vals = super(SaleInherit, self)._prepare_invoice()
        invoice_vals['my_responsible'] = self.responsible_id.name

        return invoice_vals

    # def _prepare_invoice(self):
    #     """
    #     Prepare values to create an invoice from the sale order.
    #     """
    #     invoice_vals = super(SaleInherit, self)._prepare_invoice()
    #
    #     invoice_vals['responsible_id'] = self.responsible_id.id
    #         # Add any other fields you want to pass to the invoice
    #         # For example: 'payment_term_id', 'user_id', etc.
    #
    #
    #     for line in self.order_line:
    #         invoice_line_vals = {
    #             'product_id': line.product_id.id,
    #             'soo_price_two': line.price_two,
    #
    #             # Add any other fields from the sale order line that you want to pass to the invoice line
    #         }
    #         invoice_vals['invoice_line_ids'].append((0, 0, invoice_line_vals))
    #
    #     return invoice_vals


class RepotrsaleInherit(models.Model):
    _inherit = "sale.order.line"

    price_two = fields.Float()

    # eng transfer from sale order line to account move line by function in odoo
    def _prepare_invoice_line(self, **optional_values):
        invoice_line = super(RepotrsaleInherit, self)._prepare_invoice_line(**optional_values)
        # invoice_line['intrastat_product_origin_country_id'] = self.product_id.intrastat_origin_country_id.id
        invoice_line['price_two'] = self.price_two
        return invoice_line

