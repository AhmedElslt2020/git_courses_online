from datetime import date
from email.policy import default


from odoo import models, fields, api, tools


class AccountMove(models.Model):
    _inherit = 'account.move'


    my_responsible = fields.Char(string='responsibles')









class AccountMove(models.Model):
    _inherit = 'account.move.line'

    price_two = fields.Float()


