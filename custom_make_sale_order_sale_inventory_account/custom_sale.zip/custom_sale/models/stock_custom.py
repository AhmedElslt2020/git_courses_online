from odoo import models, fields,api

class SalePickingInherit(models.Model):
    _inherit = "stock.picking"




    my_responsible = fields.Char(compute='_compute_origin', string='responsibles')

    # trasfer custom function from sale to stock.picking
    def _compute_origin(self):
        for picking in self:
            my_responsible = ''
            if picking.sale_id:
                my_responsible = picking.sale_id.responsible_id.name
            elif picking.purchase_id:
                my_responsible = picking.sale_id.responsible_id.name
            # Add more conditions for other origins if needed
            picking.my_responsible = my_responsible


class StockMoveInherit(models.Model):
    _inherit = "stock.move"

    price_two = fields.Float()

    # trasfer custom function from sale to stock.move
    @api.model
    def create(self, vals):
        if 'sale_line_id' in vals:
            sale_order_line = self.env['sale.order.line'].browse(vals['sale_line_id'])
            if sale_order_line.price_two:
                vals['price_two'] = sale_order_line.price_two

        return super(StockMoveInherit, self).create(vals)